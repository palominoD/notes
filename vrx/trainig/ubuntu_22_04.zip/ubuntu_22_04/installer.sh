#!/bin/bash


function print_usage
{
	echo "Usage: ./installer.sh -s CACHE_SIZE " #[OPTIONS...]"
	echo ""
	echo "	-s,--cache-size CACHE_SIZE		set cache size in GB"
	echo "	-h,--help				give this help list"
}


function print_usage_bad
{
	echo "bad argument..."
	print_usage
}

#check arguments
CACHE_SIZE=
PROXY=
CREDENTIALS=

while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    -s|--cache-size)
    CACHE_SIZE="$2"
    shift
    shift
    ;;
    -p|--gateway-proxy)
    PROXY="$2"
    shift
    shift
    ;;
    -c|--credentials)
    CREDENTIALS="$2"
    shift
    shift
    ;;
    -h|--help)
    print_usage
	exit 0
    ;;
    *) #bad option
    print_usage
    exit 1
    ;;
esac
done

if [ -z $CACHE_SIZE ] ; then
	print_usage_bad
	exit 1
fi

num='^[0-9]+$'
if ! [[ $CACHE_SIZE =~ $num ]] ; then
	echo "cache size:"
	print_usage_bad
	exit 1
fi
CACHE_SIZE=$(($CACHE_SIZE*1024))

proxy_format=':[0-9]+$'
if [ ! -z $PROXY ] ; then
	if ! [[ $PROXY =~ $proxy_format ]] ; then
		echo "proxy address:"
		print_usage_bad
		exit 1
	fi
fi

credentials_format='^[^:]+:[^:]+$'
if [ ! -z $CREDENTIALS ] ; then
	if ! [[ $CREDENTIALS =~ $credentials_format ]] ; then
		echo "credentials:"
		print_usage_bad
		exit 1
	fi
	if [ -z $PROXY ] ; then
		echo "credentials without proxy address:"
		print_usage_bad
		exit 1
	fi
fi

# check running privileges
if [ $(id -u) -ne "0" ]; then
	echo "installation script must run with root privileges"
	exit 1
fi

echo "~~~Vicarius proxy installation~~~"

# install packages
echo "installing proxy, please wait..."
NEEDRESTART_MODE=a apt install squid-openssl --yes > /dev/null 2>&1
echo "Checking open SSL..."
# verify installation
if ! which openssl > /dev/null 2>&1 ; then
    echo "OpenSSL is needed to complete this installation. It should be part of squid-openssl but was not installed."
	exit 1
fi

echo "Checking SQUID installation..."
if ! which squid > /dev/null 2>&1 ; then
    echo "Squid is needed to complete this installation"
	exit 1
fi


# generate CA certificate
echo "generating CA certificate..."
if ! test -f ~/.rnd ; then
    touch ~/.rnd
fi

openssl req -new -newkey rsa:2048 -days 5000 -nodes -x509 -keyout /etc/squid/selfCA.pem -out /etc/squid/selfCA.pem -subj "/C=US" > /dev/null 2>&1
if ! test -f /etc/squid/selfCA.pem ; then
    echo "failed to create CA certificate"
	exit 1
fi

echo "configuring proxy settings..."


# backup old configuration
if ! test -f /etc/squid/squid.conf.backup ; then
    cp /etc/squid/squid.conf{,.backup}
fi

# set new configuration
if ! install ./squid.logrotate /etc/logrotate.d/squid > /dev/null 2>&1 ; then
    echo "failed to set log rotate configuration"
	exit 1
fi

if ! install {./,/etc/squid/}squid.conf > /dev/null 2>&1 ; then
    echo "failed to install new configuration"
	exit 1
fi

# set cache size
sed -i "s/CACHE_SIZE/$CACHE_SIZE/g" /etc/squid/squid.conf

mkdir -p /var/lib/squid/
rm -rf /var/lib/squid/ssl_db

if ! /usr/lib/squid/security_file_certgen -c -s /var/lib/squid/ssl_db -M 100MB > /dev/null 2>&1 ; then
    echo "failed to create certificate generator"
	exit 1
fi
chown -R proxy:proxy /var/lib/squid/

if [ ! -z $PROXY ] ; then
	address=`awk '{split($0, a, ":"); print a[1]}' <<< "$PROXY"`
	port=`awk '{split($0, a, ":"); print a[2]}' <<< "$PROXY"`

	if [ ! -z $CREDENTIALS ] ; then
		echo "cache_peer ${address} parent ${port} 0 no-query no-digest login=${CREDENTIALS}" >> /etc/squid/squid.conf
	else
		echo "cache_peer ${address} parent ${port} 0 no-query no-digest" >> /etc/squid/squid.conf
	fi
	echo "never_direct allow all" >> /etc/squid/squid.conf
fi


echo "Deployment finished. Setting daemon auto recovery..."
## set service auto recovery
sed  -i '/\[Unit\]/a StartLimitIntervalSec=0' /lib/systemd/system/squid.service
sed  -i '/\[Service\]/a Restart=always' /lib/systemd/system/squid.service
sed  -i '/Restart=always/a RestartSec=10' /lib/systemd/system/squid.service
systemctl daemon-reload


# disable squid update
apt-mark hold squid-openssl


# restart with new configuration
echo "starting proxy..."
systemctl restart squid
