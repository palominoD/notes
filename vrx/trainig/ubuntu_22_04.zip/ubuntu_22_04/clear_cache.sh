#!/bin/bash

# check running privileges
if [ $(id -u) -ne "0" ]; then
	echo "installation script must run with root privileges"
	exit 1
fi

# clear cache
echo "Clearing cache..."
cp /etc/squid/squid.conf /etc/squid/squid.conf.cache
sed -i "s/cache_dir ufs.*/cache_dir ufs \/var\/spool\/squid 100 255 255/g" /etc/squid/squid.conf
squid -k reconfigure > /dev/null 2>&1
sleep 30 > /dev/null 2>&1
install /etc/squid/squid.conf{.cache,}
rm /etc/squid/squid.conf.cache
squid -k reconfigure > /dev/null 2>&1
